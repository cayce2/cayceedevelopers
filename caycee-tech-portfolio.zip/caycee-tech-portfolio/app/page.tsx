import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="container flex flex-col items-center justify-center gap-4 py-24 md:py-32">
          <div className="flex flex-col items-center gap-4 text-center">
            <Image
              src="/logo.png"
              alt="CayceeTech Logo"
              width={120}
              height={120}
              className="mb-4"
            />
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
              Where Design Meets Creativity
            </h1>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              We create innovative digital solutions that help businesses thrive in the modern world.
            </p>
            <div className="flex gap-4">
              <Button size="lg">View Our Work</Button>
              <Button size="lg" variant="outline">Contact Us</Button>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="container py-24">
          <div className="flex flex-col items-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Services</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Comprehensive solutions for your digital needs
            </p>
          </div>
          <div className="grid gap-6 mt-12 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Web Development</CardTitle>
                <CardDescription>Custom websites and web applications</CardDescription>
              </CardHeader>
              <CardContent>
                Modern, responsive websites built with the latest technologies and best practices.
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Mobile Apps</CardTitle>
                <CardDescription>Native and cross-platform solutions</CardDescription>
              </CardHeader>
              <CardContent>
                Engaging mobile experiences for iOS and Android platforms.
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>UI/UX Design</CardTitle>
                <CardDescription>User-centered design solutions</CardDescription>
              </CardHeader>
              <CardContent>
                Beautiful, intuitive interfaces that deliver exceptional user experiences.
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="container py-24 bg-muted/50">
          <div className="flex flex-col items-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Projects</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Recent work we've delivered for our clients
            </p>
          </div>
          <div className="grid gap-6 mt-12 md:grid-cols-2">
            <Card className="overflow-hidden">
              <Image
                src="/placeholder.svg"
                alt="Project 1"
                width={600}
                height={400}
                className="object-cover w-full h-48"
              />
              <CardHeader>
                <CardTitle>E-commerce Platform</CardTitle>
                <CardDescription>Full-stack web application</CardDescription>
              </CardHeader>
              <CardContent>
                A modern e-commerce solution with integrated payment processing and inventory management.
              </CardContent>
            </Card>
            <Card className="overflow-hidden">
              <Image
                src="/placeholder.svg"
                alt="Project 2"
                width={600}
                height={400}
                className="object-cover w-full h-48"
              />
              <CardHeader>
                <CardTitle>Healthcare App</CardTitle>
                <CardDescription>Mobile application</CardDescription>
              </CardHeader>
              <CardContent>
                Patient management system with real-time appointment scheduling and medical records.
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="container py-24">
          <div className="flex flex-col items-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Get in Touch</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Let's discuss your next project
            </p>
          </div>
          <Card className="max-w-2xl mx-auto mt-12">
            <CardHeader>
              <CardTitle>Contact Us</CardTitle>
              <CardDescription>Fill out the form below and we'll get back to you soon.</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="grid gap-4">
                <div className="grid gap-2">
                  <label htmlFor="name">Name</label>
                  <input
                    id="name"
                    className="w-full p-2 border rounded-md"
                    placeholder="Your name"
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="email">Email</label>
                  <input
                    id="email"
                    type="email"
                    className="w-full p-2 border rounded-md"
                    placeholder="Your email"
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="message">Message</label>
                  <textarea
                    id="message"
                    className="w-full p-2 border rounded-md"
                    rows={4}
                    placeholder="Your message"
                  />
                </div>
                <Button size="lg">Send Message</Button>
              </form>
            </CardContent>
          </Card>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}

